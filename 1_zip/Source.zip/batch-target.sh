#!/bin/bash

cd ./convert
cp * /home/deersun2/문서
